export const colors = {
    white: '#FFFFFF',
    offWhite: '#EEEFF3',
    green: '#AFE2B5',
    lightGreen: '#BDEBC2',
    blue: '#0B193D',
    black: '#000000',
    grey: '#626364',
    lightGreen2: '#D7F1DA',
    red: '#F73466',
    lightRed: '#FF6347',
    darkPink: '#E75480'
}

