require('ts-node/register');
module.exports = require('./metro.config.ts');
